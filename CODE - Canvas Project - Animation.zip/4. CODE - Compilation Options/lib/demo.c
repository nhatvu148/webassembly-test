
#include <stdio.h>

int main() {

  printf("WASM Ready - Testing with Emscripten HTML\n");
  return 1;
}
